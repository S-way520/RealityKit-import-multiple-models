import SwiftUI
import RealityKit
struct ContentView: View {
    var body: some View {
        ARViewContainer()
            .edgesIgnoringSafeArea(.all)
    }
}
struct ARViewContainer: UIViewRepresentable {
    func makeUIView(context: UIViewRepresentableContext<ARViewContainer>) -> ARView {
        let arView = ARView(frame: .zero)
        let anchorEntity = AnchorEntity(plane: .horizontal)
        guard let toyEntity = try? Entity.load(named: "toy_biplane_idle"),
              let tutorialEntity = try? Entity.load(named: "tutorial") else {
            fatalError("models is not!")
        }
        anchorEntity.addChild(toyEntity)
        anchorEntity.addChild(tutorialEntity)
        arView.scene.addAnchor(anchorEntity)
        return arView
    }
    func updateUIView(_ uiView: ARView, context: Context) {}
}
